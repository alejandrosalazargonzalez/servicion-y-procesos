package com.docencia.com.examen.procesos.domain;
/**
 * @author: alejandrosalazargonzalez
 * @version: 1.0.0
 */
public enum Job {
    DF;
}
